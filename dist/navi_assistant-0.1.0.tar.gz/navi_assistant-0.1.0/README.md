
<span style="color: magenta; font-size: 14px;">·.•°•.·.✧ ✦ 🧚 ✦</span> 
# Navi-Assistant
